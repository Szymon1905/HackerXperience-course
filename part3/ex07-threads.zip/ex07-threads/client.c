/**
 * Author: Kevin Jiokeng
 * LIX, Ecole Polytechnique
 * kevin.jiokeng@polytechnique.edu
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "message.h"

int main(int argc, char* argv[]) {
    char* server_addr;
    int port;
    
    ///////////////////////////
    // Parsing parameter values
    ///////////////////////////
    if (argc < 3) {
        fprintf(stderr, "Missing argument. Syntax: %s <SERVER_ADDRESS> <PORT>\n", argv[0]);
	    return 1;
    }
    
    server_addr = argv[1];
    port = atoi(argv[2]);

    printf("Running client for server at address %s and port %d\n", server_addr, port);

    
    

    
    return 0;
}