/**
 * Author: Kevin Jiokeng
 * LIX, Ecole Polytechnique
 * kevin.jiokeng@polytechnique.edu
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "message.h"

int main(int argc, char *argv[])
{
    ////////////////////////
    // Default params values
    ////////////////////////

    // The port on which the server should listen
    int port;

    // Maximum number of requests the server should be able to handle at the same time
    int n_requests_max = 5;

    // Processing time of each request (in microseconds)
    // You should simulate this processing by using 'usleep(delay);'
    unsigned int delay = 1000 * 1000;

    ///////////////////////////
    // Parsing parameter values
    ///////////////////////////
    if (argc < 2)
    {
        fprintf(stderr, "Missing argument. Syntax: %s <PORT> [N_REQUESTS_MAX] [DELAY_MS].\n", argv[0]);
        return 1;
    }
    else
    {
        port = atoi(argv[1]);
    }

    if (argc >= 3)
    {
        n_requests_max = atoi(argv[2]);
    }

    if (argc >= 4)
    {
        delay = atoi(argv[3]) * 1000;
    }

    printf("Running server on port %d with %d max parallel requests and %d us as delay.\n", port, n_requests_max, delay);

    // Wait for the specified delay
    usleep(delay);

    return 0;
}